# Data from: Artificial light at night and warming impact grazing rates and gonad index of the sea urchin Centrostephanus rodgersii

This README file was generated on 13-03-24 by Amelia Caley

This project is for the manuscript "Artificial light at night and warming impact grazing rates and gonad index of the sea urchin Centrostephanus rodgersii" from an experiment conducted in June - August 2022 in Sydney, Australia, testing the combined effects of Artificial Light at Night (ALAN, 50 lux) and warming (+ 2 degrees C) on urchin grazing rates and gonad index, kelp photosynthetic yield and C and N content, and on trophic interactions between urchins and kelp. The file called "Urchins ALAN Final" is the original dataset created during the experiment. This file can be imported for use with the original code, or the cleaned, long format dataset (created within this code) can be used. Photosynthetic yield, urchin gonad index and urchin grazing rates are visualised and modelled in the Urchin ALAN Analysis code, while other kelp variables (C:N ratio, C content and N content) are visualised and modelled in the kelp code. This code was written by Amelia Caley, UNSW.

GENERAL INFORMATION

1\. Title of Dataset: Artificial light at night and warming impact grazing rates and gonad index of the sea urchin Centrostephanus rodgersii

2\. Author Information:

Amelia Caley1*, Ezequiel M. Marzinelli2, Maria Byrne2, Mariana Mayer-Pinto1

1Centre for Marine Science and Innovation; Evolution & Ecology Research Centre; School of Biological, Earth and Environmental Science, University of New South Wales, Sydney, New South Wales, Australia

2The University of Sydney, School of Life and Environmental Sciences, Sydney, New South Wales, Australia

3\. Date of data collection (single date, range, approximate date): June - August 2022

4\. Geographic location of data collection: Chowder Bay, Sydney, Australia

5\. Information about funding sources that supported the collection of the data: This work was supported by an ARC Discovery Early Career Award awarded to Mayer-Pinto [DE220100308] as well as the Australian Academy of Science, Thomas Davies Research Grant for Marine, Soil and Plant Biology awarded to Mayer-Pinto in 2022.

SHARING/ACCESS INFORMATION

1\. Licenses/restrictions placed on the data: CC0 1.0 Universal (CC0 1.0) Public Domain

2\. Links to publications that cite or use the data:

Caley, A., Marzinelli, E.M., Byrne, M. & Mayer-Pinto, M. (2024). Artificial light at night and warming impact grazing rates and gonad index of the sea urchin Centrostephanus rodgersii. Philosophical Transactions of the Royal Society B: Biological Sciences.

3\. Links to other publicly accessible locations of the data: None

4\. Links/relationships to ancillary data sets: None

5\. Was data derived from another source? No

```
A. If yes, list source(s): NA
```

6\. Recommended citation for this dataset:

Caley, A., Marzinelli, E.M., Byrne, M. and Mayer-Pinto, M.,  2024. Artificial light at night and warming impact grazing rates and gonad index of the sea urchin Centrostephanus rodgersii [Dataset]. Dryad. [https://doi.org/10.5061/dryad.wpzgmsbt9](https://doi.org/10.5061/dryad.wpzgmsbt9)

DATA & FILE OVERVIEW

1\. File List:

A) Urchin_ALAN_Analysis_100124.Rmd

B) Hobo logger data files (individual files saved with serial code)

C) Urchin_ALAN_Long_Format.csv

D) Urchin_ALAN_Experiment_Data_Final_Urchins.csv

E) Kelp_Data_Final.csv

F) KelpCandN_030423.csv

2\. Relationship between files, if important: None

3\. Additional related data collected that was not included in the current data package: None

4\. Are there multiple versions of the dataset? No

```
A. If yes, name of file(s) that was updated: NA

	i. Why was the file updated? NA

	ii. When was the file updated? NA
```

\#########################################################################

Variable names

Urchin_ALAN_Long_Format.csv is the cleaned long version of Urchin_ALAN_Experiment_Data_Final_Urchins.csv (which was included for transparency alongside the clean data file)

Therefore I will describe the variables as in Urchin_ALAN_Long_Format.csv

Tank = Tank where urchin was located

Species = Species in tank (all Centrostephanus rodgersii)

ALAN = light treatment, 0 lux (dark) or ALAN (50 lux)

Temp = temperature treatment, warm (+1 degree) or ambient (ambient temperature)

Kelp = kelp treatment, either normal (kelp fed to urchin was untreated) or treated (kelp fed to urchin was treated with the same light and temperature treatment as the urchin)

Hobo.logger = serial number of hobo logger used in tank, so temperature data for tanks could be calulated

Total.Weight = total weight of urchins, in grams, measured at end of experiment

Test.diameter = test diameter of urchins in mm, measured at end of experiment

Gonad weight = wet gonad weight in grams, measured at end of experiment

Gonad index = Gonad weight/Total weight * 100 (i.e. gonad weight as a percentage of total weight), measured at end of experiment

Treatment = ALAN column + Temp column

Week = measurement week

Consumption = grams of kelp consumed in 24 hours by that urchin in that week

Group = urchin treatments and measures were staggered by 1 day. Group 1 always measured first, group 2 always measured the second (in each week).

TempLight = same as treatment column.

Variables in Kelp_data_final

Tank = tank ID with kelps

Species = species (all Ecklonia radiata)

Light = light treatment, 0 lux (dark) or ALAN (50 lux)

Temp = temperature treatment, warm (+1 degree) or ambient (ambient temperature)

Logger Serial number = serial number of hobo logger used in tank, so temperature data for tanks could be calulated

Week = measurement week

Kelp = kelp collection group (kelp collected 3 times in experiment)

Yield = photosynthetic yield measured with PAM fluorometer

Bleaching = visual assessment of bleaching percent.

Variables in KelpCandN_030423.csv

This is the output from CHNS Mass spectrometer analysis at Macquarie University. I have highlighted the fields used in this analysis.

No. = sample position in mass spectrometer

Weight  [mg] = weight of sample in mg

Name  = name of sample, either a sample standard, blank or kelp sample. Kelp samples are labelled with kelp tank (i.e. K1 - K8) and week (i.e. w1-w9).

Method = method used

N  Area = Nitrogen area

C  Area	= Carbon area

H  Area	= Hydrogen area

S  Area	= Sulfur area

N  [%] = % nitrogen content (used in analysis)

C  [%] = % carbon content (used in analysis)

H  [%]	= % Hydrogen content

S  [%] = % sulfur content

C/N  ratio = ratio of carbon to nitrogen (used in analysis)

C/H  ratio = ratio of Carbon to Hydrogen

N  Factor	= Nitrogen factor

C  Factor	= Carbon factor

H  Factor	= Hydrogen factor

S  Factor	= Sulfur Factor

N  Blank	= Nitrogen Blank

C  Blank	= Carbon Blank

H  Blank	= Hydrogen Blank

S  Blank = Sulfur blank

Note for KelpCandN_030423.csv data:

The first 13 rows are just quality controls, blanks and calibration.

Every 8 samples I also ran quality controls (QCs) and blanks (RunIns)

For all your data, we have already corrected the numbers by removing the “blank levels”. So basically no need to subtract the blanks anymore

Hobo Logger data: Data with serial codes. Matches to Hobo logger serial codes for urchin and kelp data sheets.

There are a total of 49 hobo logger files. 39 were spread across urchin tanks and 8 were in the 8 kelp tanks, and 2 were running in the air outside the tanks as spares. They measured temperature every 30 minutes for the entire experiment. This data can be found in the supplementary data files for this publication.

Plot title = Hobo logger serial number

Date Time, GMT+10:00 = date and time

Temp, °C  = temperature measured every 30 minutes

Intensity, Lux  = light intensity lux (however measurements were not accurate compared to hand held lux meter)

Coupler Attached = says "logged" when coupler attached to hobo logger

Host Connected  = says "logged" when computer connected to hobo logger

Stopped  = says "logged" when hobo logger stopped (connected to computer)

End Of File = says "logged" at end of file

4\. Missing data codes: NA (not applicable)

5\. Specialized formats or other abbreviations used: None
